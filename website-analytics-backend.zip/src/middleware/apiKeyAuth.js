const { prisma } = require('../utils/prismaClient');
const { compareApiKey } = require('../utils/apikey');

module.exports = async function apiKeyAuth(req, res, next) {
  try {
    const key = req.header('x-api-key');
    if (!key) return res.status(401).json({ error: 'Missing API key' });

    // Efficient lookup: compute HMAC or hashed id would be better.
    // For MVP we'll fetch not-revoked apps and compare.
    const apps = await prisma.app.findMany({
      where: { revoked: false },
      select: { id: true, apiKeyHash: true, name: true, expiresAt: true }
    });

    for (const app of apps) {
      const ok = await compareApiKey(key, app.apiKeyHash);
      if (ok) {
        if (app.expiresAt && new Date(app.expiresAt) < new Date()) {
          return res.status(403).json({ error: 'API key expired' });
        }
        req.appContext = { appId: app.id, appName: app.name };
        return next();
      }
    }
    return res.status(401).json({ error: 'Invalid API key' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
};
