const { prisma } = require('../utils/prismaClient');
const { generateApiKey, hashApiKey } = require('../utils/apikey');

async function register({ name, ownerEmail, expiresAt }) {
  const rawKey = await generateApiKey();
  const hash = await hashApiKey(rawKey);
  const app = await prisma.app.create({
    data: {
      name,
      ownerEmail,
      apiKeyHash: hash,
      expiresAt: expiresAt ? new Date(expiresAt) : null
    }
  });
  return {
    appId: app.id,
    name: app.name,
    ownerEmail: app.ownerEmail,
    apiKey: rawKey, // return once to user
    expiresAt: app.expiresAt
  };
}

module.exports = { register };
