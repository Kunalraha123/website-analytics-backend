const { prisma } = require('../utils/prismaClient');
const Joi = require('joi');

async function collectEvent(req, res) {
  const schema = Joi.object({
    event: Joi.string().required(),
    url: Joi.string().uri().optional(),
    referrer: Joi.string().uri().optional(),
    device: Joi.string().optional(),
    ipAddress: Joi.string().optional(),
    timestamp: Joi.date().required(),
    metadata: Joi.object().optional(),
    userId: Joi.string().optional()
  });
  const { error, value } = schema.validate(req.body);
  if (error) return res.status(400).json({ error: error.message });

  const appId = req.appContext.appId;
  try {
    await prisma.event.create({
      data: {
        appId,
        eventName: value.event,
        url: value.url,
        referrer: value.referrer,
        device: value.device,
        ipAddress: value.ipAddress || req.ip,
        userId: value.userId || null,
        timestamp: new Date(value.timestamp),
        metadata: value.metadata || {}
      }
    });
    return res.status(201).json({ status: 'ok' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
}

async function eventSummary(req, res) {
  const { event, startDate, endDate, app_id } = req.query;
  if (!event) return res.status(400).json({ error: 'event query required' });

  const where = { eventName: event };
  if (app_id) where.appId = app_id;

  if (startDate || endDate) {
    where.timestamp = {};
    if (startDate) where.timestamp.gte = new Date(startDate);
    if (endDate) {
      const d = new Date(endDate);
      d.setHours(23,59,59,999);
      where.timestamp.lte = d;
    }
  }

  try {
    const total = await prisma.event.count({ where });
    const uniqueUsers = await prisma.event.aggregate({
      _count: { userId: true },
      where: { ...where, userId: { not: null } }
    });
    // device breakdown using raw query
    const deviceAgg = await prisma.$queryRawUnsafe(
      `SELECT COALESCE(device,'unknown') as device, COUNT(*) as cnt
       FROM events
       WHERE event_name = $1 ${app_id ? "AND app_id = '" + app_id + "'" : ""} ${startDate ? "AND timestamp >= '" + startDate + "'" : ""} ${endDate ? "AND timestamp <= '" + new Date(endDate).toISOString() + "'" : ""}
       GROUP BY device;`,
      event
    );

    const deviceData = {};
    deviceAgg.forEach(r => deviceData[r.device] = Number(r.cnt));

    return res.json({
      event,
      count: total,
      uniqueUsers: uniqueUsers._count.userId || 0,
      deviceData
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
}

async function userStats(req, res) {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ error: 'userId required' });
  try {
    const totalEvents = await prisma.event.count({ where: { userId } });
    const recent = await prisma.event.findMany({
      where: { userId },
      orderBy: { timestamp: 'desc' },
      take: 10
    });
    const deviceDetails = recent.length ? (recent[0].metadata || {}) : {};
    const ipAddress = recent.length ? recent[0].ipAddress : null;
    return res.json({
      userId,
      totalEvents,
      deviceDetails,
      ipAddress,
      recentEvents: recent.map(r => ({
        event: r.eventName,
        url: r.url,
        timestamp: r.timestamp
      }))
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
}

module.exports = { collectEvent, eventSummary, userStats };
