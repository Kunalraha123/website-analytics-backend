const crypto = require('crypto');
const bcrypt = require('bcrypt');

async function generateApiKey() {
  return crypto.randomBytes(32).toString('hex');
}

async function hashApiKey(apiKey) {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(apiKey, salt);
}

async function compareApiKey(apiKey, hash) {
  return bcrypt.compare(apiKey, hash);
}

module.exports = { generateApiKey, hashApiKey, compareApiKey };
