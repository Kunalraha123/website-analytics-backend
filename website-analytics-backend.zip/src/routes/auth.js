const express = require('express');
const router = express.Router();
const { register } = require('../services/authService');
const Joi = require('joi');

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const schema = Joi.object({
    name: Joi.string().required(),
    ownerEmail: Joi.string().email().required(),
    expiresAt: Joi.date().optional()
  });
  const { error, value } = schema.validate(req.body);
  if (error) return res.status(400).json({ error: error.message });
  try {
    const result = await register(value);
    res.status(201).json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
