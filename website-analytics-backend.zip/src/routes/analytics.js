const express = require('express');
const router = express.Router();
const apiKeyAuth = require('../middleware/apiKeyAuth');
const { collectEvent, eventSummary, userStats } = require('../services/analyticsService');

// Collect events - requires API key
router.post('/collect', apiKeyAuth, collectEvent);

// Analytics endpoints
router.get('/event-summary', apiKeyAuth, eventSummary);
router.get('/user-stats', apiKeyAuth, userStats);

module.exports = router;
