require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const YAML = require('yamljs');
const swaggerUi = require('swagger-ui-express');
const rateLimit = require('express-rate-limit');
const authRoutes = require('./routes/auth');
const analyticsRoutes = require('./routes/analytics');
const { initPrisma } = require('./utils/prismaClient');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('tiny'));

// basic rate limiter (by IP) for public endpoints
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 200
});
app.use(limiter);

app.use('/api/auth', authRoutes);
app.use('/api/analytics', analyticsRoutes);

// Swagger
const swaggerDocument = YAML.load('./swagger.yaml');
app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.get('/', (req, res) => res.json({ status: 'ok', name: 'Website Analytics Backend' }));

async function start() {
  await initPrisma();
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Docs: http://localhost:${PORT}/docs`);
  });
}

if (require.main === module) {
  start();
}

module.exports = app;
